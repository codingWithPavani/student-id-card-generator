name = input("Enter your full name: ")
college = input("Enter your college name: ")
branch = input("Enter your branch: ")
year = input("Enter your year: ")
roll_no = input("Enter your roll number: ")

card = f"""
╔════════════════════════════════════════════════╗
║         🪪 STUDENT ID CARD                     ║
╠════════════════════════════════════════════════╣
║ Name     : {name:<35} ║
║ College  : {college:<35} ║
║ Branch   : {branch:<35} ║
║ Year     : {year:<35} ║
║ Roll No. : {roll_no:<35} ║
╚════════════════════════════════════════════════╝
"""

print(card)

with open("decorated_student_id_card.txt", "w", encoding="utf-8") as file:
    file.write(card)

print("🎉 Student ID card saved to 'decorated_student_id_card.txt'")
